Based on Arduino SAM Core and platform v1.6.6
